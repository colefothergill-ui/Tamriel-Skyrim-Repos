# Character: NAME

## Aspects
- High Concept:
- Trouble:
- Relationship/Hook:
- Signature Style:

## Skills (top-down)
- +4:
- +3:
- +2:
- +1:

## Stunts
- 

## Stress
- Physical: [ ] [ ] [ ]
- Mental:   [ ] [ ] [ ]

## Consequences
- Mild:
- Moderate:
- Severe:

## Notes
- Relationships / debts / oaths:
- Gear / extras:
