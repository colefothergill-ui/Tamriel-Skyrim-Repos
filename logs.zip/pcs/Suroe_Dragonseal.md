---
name: Suroe Dragonseal
type: PC
race: Sin'dorei (Blood Elf)
affiliations: [Quel'Thalas, Spellbreakers, Shado-Pan]
refresh: 1
---

![Suroe Dragonseal — Profile](assets/suroe-monk.webp)

# SUROE DRAGONSEAL — PC SHEET (Fate Core)

## Signature Detail
**Red Cloth Bandana:** Gifted by the Matriarch of House Dragonseal—worn as both blessing and reminder: *discipline before hunger, legacy before ego.*

---

## Aspects
- **High Concept:** Spellbreaker–Monk of Quel’thalas (Chi Discipline, Anti-Magic Steel)
- **Trouble:** **Dracon’Thor’reth — Hunger in the Blood (Power That Wants to Drive)**
- **Tie:** Taran’Zhu Taught Me What Was Wrong With Me (And How to Live Anyway)
- **Reputation:** Heir of House Dragonseal (A Legacy Everyone Wants to Use)
- **War Aspect:** Honor in Ugly Work

---

## Skills (Pyramid)
- **+4 Great:** Fight
- **+3 Good:** Athletics, Will
- **+2 Fair:** Physique, Stealth, **Provoke**
- **+1 Average:** Lore, Investigate, Rapport, Notice

---

## Stunts (5) — Refresh 1

### Flow Like Water — Redirecting Spiral
When you **Defend** against a **melee** attack using **Athletics** (you must have room to move—no pin/grapple/fully boxed), gain **+2** to the defense roll.  
If you **succeed with style**, you may redirect the attacker’s force onto **another enemy in the same zone**: that enemy takes up to **2 shifts** of physical stress (they may defend normally if the fiction allows). If no second target exists, take the normal Boost instead.

### Sha’do-Pan Parkour
Once per exchange, when terrain makes it plausible (roots, ruins, walls, branches, rooftops), you may **move up to 2 zones** instead of 1 and/or reach **high ground** as part of movement **without an Overcome roll**.  
If the route is genuinely blocked (sealed gate, sheer surface, hostile ward), you may still attempt it by **Overcoming with Athletics at +2**.  
If you end in a clearly advantageous position, gain a **Boost** (e.g., *High Ground*, *Perfect Angle*, *Vanished Into the Canopy*).

### Mana-Quenching Palm
**Once per scene**, when you would deal physical stress with a **Fight Attack**, you may instead **forgo the stress** to **Create an Advantage** on that target: **Drained / Interrupted Casting** with **one free invoke**.  
(Works on active casters, enchanted fighters, or anyone “perfumed” with spellwork.)

### Breath of Yu’lon
**Once per exchange**, when an enemy you can perceive attacks you, you may exhale a coiling mist and disrupt their rhythm: that attacker takes **-2 to their attack roll** against you this exchange.

### Flurry of Blows
Once per exchange, you may make a **Fight Attack** against multiple enemies in your zone:
- Choose up to **3 targets** in your zone.
- **Roll Fight once.**
- **Each target defends separately.**
- The **2nd and 3rd targets get +1** to their defense rolls (representing split focus).

---

## Extra (Trouble-Linked): Dracon’Thor’reth — Seal Charge Track
**Seal Charges:** ☐1 ☐2 ☐3 ☐4 ☐5  (max 5)

### Gaining Charges
Gain **+1 Charge** when:
- You **accept a compel** tied to Dracon’Thor’reth (you still gain the FP as normal).
- You fight in **heavy spell-saturation** (mage volleys, ritual sites, leyline spills) and don’t disengage.
- You choose **dominance over mercy** in a moment you could have de-escalated.
- You take **1+ stress** from physical/mental harm (the seal “answers” pain).

### Overheat (Cost of Feeding the Dragon)
- If you ever hit **5/5 Charges**, the GM immediately offers a compel: **“The Dragon Takes the Wheel.”**
  - **Accept:** gain **+1 FP** and you must act with brutal immediacy (no subtle option this beat).
  - **Resist:** take a **Mild consequence** (*Blood-Heat Tremors* / *Burning Veins*) and drop to **3 Charges**.
- Any time you spend **3+ Charges in a single exchange**, at the end of that exchange you must check **1 Mental Stress** (or take a Mild consequence if you can’t).
- At the **end of the scene**, if you spent **5+ Charges total**, gain the scene aspect **EXPELLED HARMFUL CHI** on you with **1 free invoke for the opposition**.

### Seal Techniques (Charge-Based)
These are powerful techniques fueled by the seal. Charges are spent **after rolling** unless noted.

#### Dragon-Fury Guard (Cost: 1–2 Charges)
When you **Defend** with **Fight or Athletics**, you may spend:
- **1 Charge:** gain **+2** to the defense roll.
- **2 Charges:** gain **+2**, and if you **succeed**, you also **Create an Advantage** on the attacker: **OFF-BALANCE / SHOOK** with **1 free invoke**.

#### Sun-Dragon Breaker (Cost: 2–3 Charges)
When you **Attack** with **Fight** (unarmed or monk weapon), you may spend:
- **2 Charges:** Your strike gains **Weapon:2** for this hit.
- **3 Charges:** Weapon:2, and on a hit you may also **Create an Advantage** on the target: **CHANNELS SEVERED / WIND KNOCKED OUT** with **1 free invoke** (in addition to damage).

**Flurry interaction:** When using **Flurry of Blows**, you may spend **1 Charge** to remove the +1 defense bonus from the 2nd and 3rd targets for this Flurry.

---

## Stress & Consequences
**Physical Stress** (Physique +2): ☐1 ☐2 ☐3  
**Mental Stress** (Will +3): ☐1 ☐2 ☐3 ☐4  

**Consequences:**  
- **Mild (2):** ______________________________  
- **Moderate (4):** __________________________  
- **Severe (6):** ____________________________

---

## Notes (Invokes & Compels)
### High Concept — Spellbreaker–Monk
**Invoke:** anti-magic tactics, disciplined martial control, shutting down casters, battlefield clarity.  
**Compel:** anti-magic reputation draws specialist counters; enemies bait you into mage-duels.

### Trouble — Dracon’Thor’reth Hunger
**Invoke:** when you *ride* the hunger (intimidation, relentless pursuit, “no hesitation”).  
**Compel:** spell-saturation triggers cravings; deprivation makes you reckless; humiliation makes the seal flare.

### Tie — Taran’Zhu’s Teaching
**Invoke:** calm under pressure, restraint, meditative insight, resisting corruption.  
**Compel:** you refuse shortcuts; you pause when others want brutality; you’re pulled toward “the right way” even when costly.

### Reputation — Heir of House Dragonseal
**Invoke:** legacy respect, Dragonseal discipline, political weight, expectations of leadership.  
**Compel:** people try to use you (Rommath, nobles, officers); your actions reflect on the whole house; scandals hit harder.

### War Aspect — Honor in Ugly Work
**Invoke:** decisive mercy, clean captures, refusing cruelty while still winning.  
**Compel:** you take prisoners when killing would be easier; you make offers before violence; you keep your word even when inconvenient.
