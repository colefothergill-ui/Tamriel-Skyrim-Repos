# Suroe Dragonseal — Campaign Hooks

## Relic Line
- Dracon’o Belore may be entombed, stolen, fragmented, or politically hidden. Its recovery is a campaign lever.
- Reclaiming the relic risks: addiction relapse, political seizure, or “weaponization” by state actors.

## House Restoration
- Dragonseal can regain influence via service, victories, and humanitarian acts.
- The risk is scandal: one hunger-flare incident could undo decades.

## Relationship Levers
- Rommath: pragmatic patronage with sharp boundaries (results matter; optics matter).
- Aethrya: bitter respect that can evolve into vendetta or reluctant cooperation.

## War-Facing Consequences
- Capturing officers invites retrieval raids and political escalation.
- Mercy generates leverage; cruelty generates certainty (and a lot more arrows).
