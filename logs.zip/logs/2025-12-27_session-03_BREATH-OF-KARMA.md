---
title: "Session 03 — Breath of Karma"
date: "2025-12-27"
chapter: 2
campaign: "BFA"
location: "Ashenvale"
characters:
  - "Suroe Dragonseal"
tags:
  - session-log
  - chapter-2
  - ashenvale
  - suroe-dragonseal
---

# Chapter 2: Sealing Our Fate - Part Three

Ashenvale did not greet the intruders with song.

It greeted them with that damp, listening hush that only old forests can manage—the kind of quiet that makes even veterans swallow their breathing and weigh each footfall like an oath. High in the canopy, where the oaks stretch like cathedral pillars and mist coils between branches as if it has errands, Suroe Dragonseal held the war in his palm and decided where it would bleed.

Captain Aethrya Moonshadow remained bound and upright, her injuries sharp enough to demand mercy but her will too disciplined to ask for it. She watched Suroe the way a huntress watches a storm forming over the sea: not hopeful, not pleading—only measuring. Her hatred was clean, honed, and strangely honest. She did not speak of rescue as sentiment. She spoke of it as law. Sentinels do not leave their own behind.

Suroe answered that truth with a soldier's understanding and a monk's calm—until the monk began to fracture into something older. He did not rush the moment. He let it ripen. He allowed the forest's watchers to commit, to step fully into the shape of their intent, and only then did he crush crimson vapor between his hands as if closing a fist around fate itself.

Red fog erupted across the kill lanes in staggered blooms—brief detonations that turned certainty into hesitation. In that half-blink where perfect coordination stutters, Sin'dorei dropped from the canopy like knives loosed from prayer. The first exchange was not glorious; it was efficient. Limbs folded. Breath left bodies in blunt, unromantic bursts. Steel flashed only when needed. In the confusion, a Shadowblade—leader and hinge of the retrieval—tried to vanish into the mist and regain the forest's rhythm.

Suroe followed.

Not with the heavy pursuit of a soldier chasing a fleeing foe, but with the predatory mathematics of a master—silent drops, impossible angles, footwork that treated gravity as suggestion. He intercepted her outside the forest's prepared lanes before she could lure him into their teeth. Then he turned his own brutality into misdirection: crimson thunder spilled outward in a sweeping gale, and within that boiling cloud he crafted a lie convincing enough to make a veteran cut at air. She struck a silhouette. He arrived at her throat.

His hand was ice.

Not winter. Not water. Something worse—cold that belongs to graves and vows and mistakes that cannot be undone. The palm that landed there did not merely harm. It took. The Shadowblade's shadow-magic juddered as if the world refused to hold her in the same place twice. Her breath hitched. Her strength failed in increments. For one heartbeat she seemed less a hunter and more prey realizing too late that the rules had changed.

Then Dracon Thor'reth ignited.

It was sudden—violent in its awakening, like a sealed reservoir bursting into a drought-stricken riverbed. Light flared beneath Suroe's skin. His eyes lit fel-green at the edges, and the discipline that had held him like a spine began to bend beneath a heavier presence: the curse of Malygos pressing its teeth into his thoughts. The monk in him recognized the line. The seal in him laughed at it.

The Shadowblade was not a robe-and-staff caster, but she carried moon-shadow art in her blood: wards, sigils, breath-technique magic, enough to fuel the kind of violence that does not apologize. Suroe's grip tightened. Mana poured from her like a vein opened to the air. His muscles swelled with stolen fire. Her body slackened as if her spirit had been pulled slightly out of alignment with her flesh. It was not a clean kill. It was infamous. It was the sort of death that becomes story, and story becomes rallying cry.

Captain Aethrya's reaction was not a scream. It was a vow being born, raw and immediate, as if the forest itself had placed a blade in her hand and whispered a name.

Horns answered in the distance—multiple calls, triangulated, disciplined. Not a parade battalion, but a hunt-company: squads converging from different angles, druids ready to anchor roots and wards into the soil, archers prepared to turn the canopy into a slaughterhouse for anyone foolish enough to run straight. They came for their captain. They came for retribution. They came because Ashenvale does not forget its own.

Suroe met them with a smile that didn't reach the part of him still counting breaths.

His voice doubled and echoed as if something else spoke through his throat. He mocked the ancient magic rooting through their old bones—called it cold and stale, unworthy of slowing him. The land reacted to that laughter like a bruise being pressed. Leaves trembled. Mist recoiled. The forest did not like him. It did not like what was riding him.

And then he did the unthinkable.

He inhaled, abdomen tightening as if something writhing climbed his spine. When he exhaled, it was not breath. It was an upchoked tide—boiling crimson mist that fanned outward across the advancing Kaldorei like a corrosive wave. Where it touched skin and ward, mana reservoirs inflamed and overheated. Druids collapsed, clutching at their own power as if it had turned to acid in their veins. Roots that should have answered their call faltered. Moon-sigils flickered. Coordination snapped. The hunt-company did not vanish—but it broke, scattering into survival, dragging the wounded back into the trees with the desperate focus of soldiers who suddenly understood they were fighting something that did not obey normal rules.

Ashenvale learned Suroe's scent in that moment.

So did the Kaldorei.

And so did Suroe.

There are deeds that win battles and lose futures. There are moments where a name stops being a man's and becomes a warning. In the wake of crimson fog and fel-lit eyes, the Sentinels would not speak of him as a mere captor or raider. They would tell the story with a harder word. They would brief patrols differently. They would prepare countermeasures. They would hunt with new hatred, because now they had proof: the monster in their stories could breathe.

Above it all, Captain Aethrya remained bound—alive, furious, and staring at Suroe as if she had just watched a sacred text burn. The forest stirred deeper in the dark, old things shifting their weight as if waking from uneasy sleep. The war moved forward, and consequences moved with it, patient as roots.
