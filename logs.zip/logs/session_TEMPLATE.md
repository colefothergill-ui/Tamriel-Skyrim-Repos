# Session YYYY-MM-DD — Title

## Save Game (narrative)
*(Write the story recap here.)*

## Mechanical Updates
- **Clocks updated:** (edit `clocks/bfa_clocks.json`)
- **New Aspects created:** 
- **Invokes banked:** 
- **Consequences taken/cleared:** 
- **New Stunts/Extras:** 

## Open Threads / Next Scenes
- 
