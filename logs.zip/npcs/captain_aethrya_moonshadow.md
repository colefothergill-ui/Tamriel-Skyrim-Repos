# Captain Aethrya Moonshadow (Kaldorei Sentinel)

## Role
Sentinel field-captain tasked with Ashenvale canopy screen & counter-scout operations.

## High Concept
**Sentinel Captain of the Canopy Screen**

## Trouble
**Pride That Won’t Bow (Even When It Should)**

## Other Aspects
- “The Forest Keeps My Secrets”
- “Discipline Over Comfort”
- “I Don’t Leave My People Behind”

## Current Status
Captured (binding/escorted by Suroe’s unit), wounded but lucid.

## Consequences (current)
- Moderate: **Shattered Shoulder**
- Mild: **Gored Thigh**

## Notes for GM Use
Aethrya will not beg. She will negotiate terms, attempt to protect her people, and remember every insult forever. She is most dangerous when given time to plan, allies to coordinate, or a moral high ground to stand on.
